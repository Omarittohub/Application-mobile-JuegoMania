struct GameItems: Identifiable {
    let id: Int
    let name: String
    let price: String
    let seller: String
    var mis_en_vente: Bool
    let quantite: Int
}
